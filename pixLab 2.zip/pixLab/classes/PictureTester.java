/**
 * This class contains class (static) methods
 * that will help you test the Picture class 
 * methods.  Uncomment the methods and the code
 * in the main to test.
 * 
 * @author Barbara Ericson 
 */
public class PictureTester
{
  /** Method to test zeroBlue */
  public static void testZeroBlue()
  {
    Picture beach = new Picture("images/beach.jpg");
    beach.explore();
    beach.zeroBlue();
    beach.explore();
  }
  
  /** Method to test mirrorVertical */
  public static void testMirrorVertical()
  {
    Picture caterpillar = new Picture("/Users/Gordon/Downloads/pixLab/classes/images/think.png");
    caterpillar.explore();
    caterpillar.mirrorVertical();
    caterpillar.explore();
  }

  public static void testMirrorVerticalRightToLeft()
  {
    Picture caterpillar = new Picture("/Users/Gordon/Downloads/pixLab/classes/images/think.png");
    caterpillar.explore();
    caterpillar.mirrorVerticalRightToLeft();
    caterpillar.explore();
  }
  public static void testMirrorHorizontal()
  {
    Picture caterpillar = new Picture("/Users/Gordon/Downloads/pixLab/classes/images/snowman.jpg");
    caterpillar.explore();
    caterpillar.mirrorHorizontal();
    caterpillar.explore();
  }
  
  /** Method to test mirrorTemple */
  public static void testMirrorTemple()
  {
    Picture temple = new Picture("/Users/Gordon/Downloads/pixLab/classes/images/temple.jpg");
    temple.explore();
    temple.mirrorTemple();
    temple.explore();
  }

  public static void testMirrorSnowman()
  {
  Picture temple = new Picture("/Users/Gordon/Downloads/pixLab/classes/images/snowman.jpg");
  temple.explore();
  temple.mirrorArms();
  temple.explore();
  }
  public static void testMirrorGull()
  {
    Picture temple = new Picture("/Users/Gordon/Downloads/pixLab/classes/images/seagull.jpg");
    temple.explore();
    temple.mirrorGull();
    temple.explore();
  }
  
  /** Method to test the collage method */
  public static void testCollage()
  {
    Picture canvas = new Picture("/Users/Gordon/Downloads/pixLab/classes/images/640x480.jpg");
    canvas.myCollage();
    canvas.explore();
  }
  
  /** Method to test edgeDetection */
  public static void testEdgeDetection()
  {
    Picture swan = new Picture("/Users/Gordon/Downloads/pixLab/classes/images/think.png");
    swan.edgeDetection(10);
    swan.explore();
  }
  private static void testKeepOnlyBlue() {
    Picture think = new Picture("/Users/Gordon/Downloads/pixLab/classes/images/think.png");
    think.explore();
    think.keepOnlyBlue();
    think.explore();
  }
  private static void testNegate() {
    Picture think = new Picture("/Users/Gordon/Downloads/pixLab/classes/images/think.png");
    think.explore();
    think.negate();
    think.explore();
  }
  private static void testGrayscale() {
    Picture think = new Picture("/Users/Gordon/Downloads/pixLab/classes/images/think.png");
    think.explore();
    think.grayscale();
    think.explore();
  }
  private static void testFixUnderwater() {
    Picture think = new Picture("/Users/Gordon/Downloads/pixLab/classes/images/water.jpg");
    think.explore();
    think.fixUnderwater();
    think.explore();
  }
  private static void testChromakey() {
    Picture ball = new Picture("/Users/Gordon/Downloads/pixLab/classes/images/ball.png").scale(1,1);
    Picture snowman = new Picture("/Users/Gordon/Downloads/pixLab/classes/images/snowman2.png").scale(0.34,0.34);
    ball.explore();
    ball.red();
    ball.explore();
  }
  private static void testRed() {
    Picture think = new Picture("/Users/Gordon/Downloads/pixLab/classes/images/think.png");
    think.explore();
    think.red();
    think.explore();
  }

  /** Main method for testing.  Every class can have a main
    * method in Java */
  public static void main(String[] args)
  {
    // uncomment a call here to run a test
    // and comment out the ones you don't want
    // to run
    //testFixUnderwater();
    //testZeroBlue();
    //testKeepOnlyBlue();
    //testKeepOnlyRed();
    //testKeepOnlyGreen();
    //testNegate();
    //testGrayscale();
    //testFixUnderwater();
    //testChromakey();
    //testMirrorHorizontal();
    //testMirrorTemple();
    //testMirrorSnowman();
    //testMirrorGull();
    //testMirrorArms();
    //testMirrorGull();
    //testMirrorDiagonal();
    //testCollage();
    //testCopy();
    //testEdgeDetection();
    //testEdgeDetection2();
    testRed();
    //testChromakey();
    //testEncodeAndDecode();
    //testGetCountRedOverValue(250);
    //testSetRedToHalfValueInTopHalf();
    //testClearBlueOverValue(200);
    //testGetAverageForColumn(0);
  }
}